import matplotlib.pyplot as plt
from wordcloud import WordCloud
from collections import Counter
import re
from nltk.corpus import stopwords
import string
from collections import defaultdict
import operator
import math
import spacy


# incializando varaiveis
p_t = {}
p_t_com = defaultdict(lambda : defaultdict(int))
com = defaultdict(lambda : defaultdict(int))
pmi = defaultdict(lambda : defaultdict(int))
punctuation = list(string.punctuation)
stop = stopwords.words('portuguese') + punctuation
count_stop_single = Counter()
nlp = spacy.load('pt_core_news_sm')
 
emoticons_str = r"""
    (?:
        [:=;]
        [oO\-]?
        [D\)\]\(\]/\\OpP]
    )"""
 
regex_str = [
    emoticons_str,
    r'<[^>]+>', # HTML
    r'(?:@[\w_]+)', # @ marcacoes
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", # hash-tags
    r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&amp;+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+', # URLs
    r'(?:[\w_]+)', # outras palavras
]

tokens_re = re.compile(r'('+'|'.join(regex_str)+')', re.VERBOSE | re.IGNORECASE)
emoticon_re = re.compile(r'^'+emoticons_str+'$', re.VERBOSE | re.IGNORECASE)
 


# ----------- FUNÇÕES AUXILIARES--------------

# TOKENIZA OS TWEETS
def tokenize(s):
    return tokens_re.findall(s)

# PRE PROCESSAMENTO
def preprocess(s, lowercase=True):
    tokens = tokenize(s)
    if lowercase:
        tokens = [token if emoticon_re.findall(token) else token.lower() for token in tokens]
        tokens = [re.sub('[0-9]|,|betina| ', '', token) for token in tokens  if len(token) > 3]
        return tokens

# GERA UMA WORDCLOUD
def TTwordcloud(tweets,name_file):
    wordcloud = WordCloud( width=1600, height=800).generate(tweets)
 
    # mostrar a imagem final
    fig, ax = plt.subplots(figsize=(10,6))
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.set_axis_off()
     
    plt.imshow(wordcloud);
    wordcloud.to_file(name_file)
    
    
    
    
    
    
    
if __name__ == '__main__':
    # -----------------------carregando tweets e lexico da expansão 1------------------------------ 
    dataset_tweets = 'allTweets.csv'
    lexico_expansao1_pos = 'extend1_pos.txt'
    lexico_expansao1_neg = 'extend1_neg.txt'
    
   
    
    # ----- carregandondo tweets 
    
    # (substituia o allTweets.csv pelos csv dos tweets que deve ser usado como referencia )
    TT = [line.strip() for line in open(dataset_tweets, encoding='utf8')]
    
    
    
    # ----- carregando lexicon seeds 
    
    # (substitua o extend_pos.txt pelo txt gerado na primeira expansão)
    positive_txt = open(lexico_expansao1_pos, 'r').readlines()
    positive_vocab = []
    for word in positive_txt:  positive_vocab.append(word.replace('\n', '') ) # eliminando \n das palavras
     
    # (substitua o extend_pos.txt pelo txt gerado na primeira expansão)
    negative_txt = open(lexico_expansao1_neg, 'r').readlines()
    negative_vocab = []
    for word in negative_txt: negative_vocab.append(word.replace('\n', '') )
    
    
    # inicializando algumas variaveis
    tweets_preproce =[]
    resultado= ""
    TT_preprocess=""
    n_docs=0
    
    
    # ----------------------------------------------------- 
    
    
    
    # WordCloud antes do preprocessamento 
 
    #words_tt = " ".join(s for s in TT) # cria uma lista com cada palavra de todos os tweets TT
    #TTwordcloud(words_tt,'wcTT.png')

    
    
    # -------------PRE PROCESSAMENTO--------------------
    for line in TT:
        
        tokens_tt = preprocess(line)
        
        # apenas tweets com mais que 3 palavras
        if len(tokens_tt) < 3: continue
    
        n_docs+=1
        
        #limpando stopwords e limpando possiveis ruidos
        terms_only = [term for term in tokens_tt 
                      if term not in stop and not term.startswith(('#', '@', 'http'))]
        
        tweets_preproce.append(terms_only)
        
        # guarando as palavras para wordclound após o pre processamento
        tweet_preprocess= " ".join(s for s in terms_only)
        TT_preprocess = TT_preprocess+" "+tweet_preprocess
    
        print(terms_only)
        count_stop_single.update(terms_only)             
               
        
            
        # criando a matriz de co ocorrencia
        for i in range(len(terms_only)-1):
            for j in range(i+1, len(terms_only)):
                w1, w2 = sorted([terms_only[i], terms_only[j]])
                if w1 != w2:
                    com[w1][w2] += 1
    
    
    
    
    #  -------- CONTAGEM DE TERMOS -------------
    
    # WordCloud depos do preprocessamento
    TTwordcloud(TT_preprocess,'PREPOSwcTT.png')
    
    
    
    # Pra cada termo, procurando o termos com maior co ocorrencia
    com_max = []
    for t1 in com:
        t1_max_terms = sorted(com[t1].items(), key=operator.itemgetter(1), reverse=True)[:5]
        for t2, t2_count in t1_max_terms:
            com_max.append(((t1, t2), t2_count))
            
    # termos com maior co ocorrencia
    terms_max = sorted(com_max, key=operator.itemgetter(1), reverse=True)
    print("Termos com maior co ocorrencia",'\n',terms_max[:5])
   
    
   
   
   
    #      PMI
    
    word_ocorrencia = [] 
    
    # calculando p_t = prob(termo) e p_t_com = prob(term1,termo2)
    for term, n in count_stop_single.items():
        word_ocorrencia.append(n)    
        if n > 12:  # permitindo apenas palavras com mais de 12 ocorrencias (recomendo manter no minimo 10)
            p_t[term] = n / n_docs
            for term2 in com[term]:
                p_t_com[term][term2] = com[term][term2] / n_docs
        
    #Calculo PMI pegando sinonimos e anontimos da palavra =  lucrar
    for word1 in p_t:
        if bool(com[term]) == True:
            for word2 in com[word1]:
                if word2 in p_t:
                    denom = p_t[word1] * p_t[word2]
                    pmi[word1][word2] = math.log2(p_t_com[word1][word2] / denom)
     
    # calculo do sentimento    
    semantic_orientation = {}
    for term, n in p_t.items():
        positive_assoc = sum(pmi[term][tx] for tx in positive_vocab)
        negative_assoc = sum(pmi[term][tx] for tx in negative_vocab)
        semantic_orientation[term] = positive_assoc - negative_assoc

    semantic_sorted = sorted(semantic_orientation.items(), key=operator.itemgetter(1),reverse=True)
    
    
    
    
    # ------------------ PLOTS para avaliar o resultado final-----------------
    
    #para wordclound
    
    list_posit = []
    list_neg = []
    
    for key, value in semantic_orientation.items():
        if value > 3: #   positivos
            list_posit.append(key)
        elif value < -3: #   negativos
            list_neg.append(key)
        
    words_positivos= " ".join(s for s in list_posit)
    
    str_wordsPositivos = ""
    str_wordsPositivos = str_wordsPositivos+" "+words_positivos
    
    words_neg= " ".join(s for s in list_neg)
    
    str_wordsNegativos = ""
    str_wordsNegativos = str_wordsNegativos+" "+words_neg
    
    
    # distribuicao de sentiment scores
    sementin_scores = []
    for key, value in semantic_orientation.items():
        sementin_scores.append(value)
        
    plt.hist(sementin_scores, bins=range(-45, 45,3))
    
    # distruibuicao de ocorrencia de palavras
    plt.hist(word_ocorrencia, bins=range(0,40,1))
     
    
    # WordCloud depos do preprocessamento
    TTwordcloud(str_wordsPositivos,'wcPOSITIVE.png')
    TTwordcloud(str_wordsNegativos,'wcNEGATIVE.png')
    
    
    
    # -------- Resultado dos top 10 mais postivos e mais negativos ----------------
    top_pos = semantic_sorted[:10]
    top_neg = semantic_sorted[-10:]
    
    print(top_pos)
    print(top_neg)



    # --------------------- EXTENDER LEXICON--------------------
    #aqui será criado a nova e ultima verção do lexico
    
    #criando os arquivos
    extend_pos = open('lexiconv2_pos.txt', 'w')
    extend_neg = open('lexiconv2_neg.txt', 'w')

    # gravando no arquivo
    extend_pos.writelines( "%s\n" % (word.lstrip(' ') ) for word in positive_vocab)
    extend_neg.writelines( "%s\n" % (word.lstrip(' ') ) for word in negative_vocab)
    
    extend_pos.writelines( "%s\n" % (word.lstrip(' ') ) for word in list_posit
                         if word not in positive_vocab)
    
    extend_neg.writelines( "%s\n" % (word.lstrip(' ') ) for word in list_neg
                         if word not in negative_vocab)
    
    extend_pos.close()
    extend_neg.close()