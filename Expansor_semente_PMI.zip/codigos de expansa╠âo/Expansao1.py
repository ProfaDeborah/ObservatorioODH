from babelnetpy.babelnet import BabelNet # babelnet.org/guide API EM https://github.com/jackee777/babelnetpy
from nltk.corpus import wordnet as wn
from googletrans import Translator # https://pypi.org/project/googletrans/
from unidecode import unidecode
import spacy


def buscar_traducao(palavra, dic):
    resultado = []
    
    for line in dic:
        line_str = ( "".join(line) ).split("=")
        
        if palavra in line_str[0]:
            for word in line_str[1].split(","):
                resultado.append( "".join( word ).replace('\n', '') )
            break
    
    return resultado



if __name__ == "__main__":
    
    # substituia o pelo caminho do arquivo
    
    lexico_semente_positiva = 'seed_pos.txt'
    lexico_semente_negativo = 'seed_neg.txt'
    
    
    
    # inicialização das bibliotecas e arquivos
    dicionario = open('eng_pt.txt', 'r',encoding="latin-1")
    dic = dicionario.readlines()
    
    # lendo lexico semente *troque o seed_pos.txt e seed_neg.txt pelo nome dos lexicon seed*
    seed_pos = open(lexico_semente_positiva, 'r')
    list_pos = seed_pos.readlines()
    seed_neg = open(lexico_semente_negativo, 'r')
    list_neg = seed_neg.readlines()
    
    # criando os arquivos que será atribuido a primeira expansão
    extend_pos = open('extend1_pos.txt', 'w')
    extend_neg = open('extend1_neg.txt', 'w')
    
    # NUMERO DA API GERADO
    api = BabelNet('c9134b5b-0042-49e2-a401-c6bda7431b58') #CRIE UM NOVO SERIAL EM 
    nlp = spacy.load('pt_core_news_sm')
    translator = Translator()
    
    
    resultado = []
    def ext_list(list_seed,status):
        
        sinonimos = []
        antonimos = []
        
        # adiciona a lista seed em sinonimos
        sinonimos.extend( word.replace('\n', '') for word in list_seed )
        
        if status == 0:
            extend_pos.writelines( word_seed for word_seed in list_seed)
        else:
            extend_neg.writelines( word_seed for word_seed in list_seed)
        
        # lematizacao 
        
        doc = nlp(','.join(list_seed))
        
        resultado = [token.lemma_ for token in doc if token.pos_ in ('VERB','NOUN','ADJ','ADV') ]
        
        
        
        # sinonimos e antonimos
        
        for palavra in resultado:
            print("pegando sinonimos e anontimos da palavra = ",palavra)
            Ids = api.getSynset_Ids( "".join(unidecode(palavra)), "PT")
            
            # controle de caso a palavra não exista 
            if Ids:
                syn = api.getSynsets(Ids[0].id)
            else:
                continue
            
            # sinonimos
            for word in syn[0].senses:
                if word['properties']['fullLemma'] not in sinonimos:
                    
                    if status == 0:
                        extend_pos.writelines( "%s\n" % (word['properties']['fullLemma']).lstrip() )
                    else:
                        extend_neg.writelines( "%s\n" % (word['properties']['fullLemma']).lstrip() )
                        
                    sinonimos.append( word['properties']['fullLemma'] ) 
            
            #antonimos
            for syn in wn.synsets("".join(palavra), lang='por'):
                for l in syn.lemmas():
                    if l.antonyms():
                        
                        words_traduzido = buscar_traducao( l.antonyms()[0].name() , dic)
                        
                        if len(words_traduzido) == 0:
                            #print("nao tem ",l.antonyms()[0].name(),'\n')
                            words_traduzido.append(translator.translate(l.antonyms()[0].name(), dest='pt', en='en').text)
                        
                       #print("resultado de ", l.antonyms()[0].name(), " traduzido ",words_traduzido, '\n')
                        for word_a in words_traduzido:
                            if word_a not in antonimos:
                                if status == 0:
                                    extend_neg.writelines( "%s\n" % (word_a.lstrip(' ') ))
                                else:
                                    extend_pos.writelines( "%s\n" % (word_a.lstrip(' ') ))
                                    
                                antonimos.append( word_a )
        
        
    
    ext_list(list_pos,0)
    #ext_list(list_neg,1)
    
    seed_pos.close()
    seed_neg.close()
    extend_pos.close()
    extend_neg.close()
    dicionario.close()
