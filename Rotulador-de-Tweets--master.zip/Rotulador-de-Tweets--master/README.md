# Rotulador-de-Tweets-
Rotulador de Tweets desenvolvido em um projeto de iniciação científica do Instituto de Informática da Universidade Federal de Goiás
